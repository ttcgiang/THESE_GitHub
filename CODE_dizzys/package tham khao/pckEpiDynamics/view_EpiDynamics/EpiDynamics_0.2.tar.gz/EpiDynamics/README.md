Epidynamics
===========

Currently, the R package `EpiDynamics` implements the computer programs written in other programming languages and available in the web page of the book referenced below:  

Keeling, M.J. and Rohani, P. (2007) Modeling Infectious Diseases in Humans and Animals. Princeton University Press.

The EpiDynamics' functions corresponding to the programs of the book are based on the Python versions written by Ilias Soumpasis.