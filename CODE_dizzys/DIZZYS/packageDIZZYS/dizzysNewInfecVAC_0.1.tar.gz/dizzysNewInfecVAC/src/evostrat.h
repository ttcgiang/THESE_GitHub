/*
 *  evostrat.h
 *  EvoStrat
 *
 *  Created by yann chevaleyre on 24/11/11.
 *  Copyright 2011 __MyCompanyName__. All rights reserved.
 *
 */

#include <iostream>
#include <vector>
#include <string>
#include "randYANN.h"
using namespace std;

typedef vector<double> double_vector;

//double normal_distribution();
//void test_normal_distribution();

void test_evo_strat();
//double_vector evo_strat(double_vector v0, int ntrials, double sigma, bool adaptive, double_vector* fitness_sequence, int nbVilles, double sigma, double gamma, double mu, unsigned long **valSEIR0, double beta0, double beta1, double *phi, double seed, double unitTIME, double tmax, double typeRNG, double periDISE, double **arr_probVISITER, double **arrNbCONTACT0, double **arrNbCONTACT1, double **arr_probINFECTER, double **arr_probVENIRk, double tstart, double tstop, double totalVac, double periodVac, double vaccRate);
double_vector evo_strat(double_vector v0, int ntrials, double sigmaDis, bool adaptive, double_vector *fitness_sequence,
                        //for simulation
                        int nbVilles, double sigma, double gamma, double mu, unsigned long **valSEIR0,
                        double beta0, double beta1, double *phi,
                        // for simulation
                        double seed, double unitTIME, double tmax, double typeRNG, double periDISE,
                        // for metapopulation
                        double** arr_probVISITER, double** arrNbCONTACT0, double** arrNbCONTACT1,
                        double** arr_probINFECTER, double** arr_probVENIRk,
                        //vaccination
                        double tstart, double tstop, double totalVac, double periodVac, double vaccRate);

