/*
 *
 *  Created by yann chevaleyre on 24/11/11.
 *  Copyright 2011 __MyCompanyName__. All rights reserved.
 *
 */

#include <iostream>
#include <vector>
#include <string>
#include "index.h"

using namespace std;


//normal distribution
double normal_distribution();

//random number generator according to the normal distribution
float ran1(int *idum,int mode,char* line);




