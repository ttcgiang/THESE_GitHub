# all dizzysNewInfec demos
demo(globaldizzysNewInfec)
demo(plot.simul.cont)
demo(sirmodel)
demo(seir.stoch)


